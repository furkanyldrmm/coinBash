



<footer id="footer">
    <div class="container">
        <div class="row"><!-- row -->

            <div class="col-lg-3 col-md-3"><!-- widgets column left -->
                <ul class="list-unstyled clear-margins"><!-- widgets -->
                    <li class="widget-container widget_nav_menu"><!-- widgets list -->

                        <h1 class="title-widget">Quick Links</h1>
                        <ul>
                            <li class="scroll "><a href="#home" title="Surgenex Main Content"> Home</a></li>
                            <li class="scroll "><a href="#aboutus" title="Surgenex About US"> About Us</a></li>
                            <li class="scroll "><a href="#manufacturing" title="Surgenex Manufacturing and Quality Assurance"> Manufacturing</a></li>
                            <li class="scroll "><a href="#research" title="Research Development Amniotic Membrane Research"> Research</a></li>
                            <li class="scroll "><a target="_blank" href="faq.html" title="Frequently Asked Top Questions"> FAQ</a></li>
                            <li class="scroll "><a target="_blank" href="#contact" title="Contact form for Surgenex"> Contact Us</a></li>
                            <li class="scroll "><a target="_blank" href="https://SURGENEX.com/records/" title="Login Surgenex to add records"> Login</a></li>

                        </ul>
                    </li>
                </ul>
            </div><!-- widgets column left end -->

            <div class="col-lg-3 col-md-3"><!-- widgets column left -->
                <ul class="list-unstyled clear-margins"><!-- widgets -->
                    <li class="widget-container widget_nav_menu"><!-- widgets list -->
                        <h1 class="title-widget">Product Link</h1>
                        <ul>
                            <li><a  href="#"><i class="fa fa-star"></i> <a target="_blank" href="http://www.surgenexproducts.com/" title="Surgenex Product Surforce"> SurForce</a></li>
                        </ul>
                    </li>
                </ul>
            </div><!-- widgets column left end -->
            <div class="col-lg-3 col-md-3"><!-- widgets column left -->
                <ul class="list-unstyled clear-margins"><!-- widgets -->
                    <li class="widget-container widget_nav_menu"><!-- widgets list -->
                        <h1 class="title-widget">Usage</h1>
                        <ul>
                            <li class="scroll "><a href="terms.html" title="Surgenex Website Terms"> Terms</a></li>
                            <li class="scroll "><a href="privacy.html" title="Surgenex Website Privacy"> Privacy</a></li>
                        </ul>
                    </li>
                </ul>
            </div><!-- widgets column left end -->
            <div class="col-lg-3 col-md-3"><!-- widgets column left -->
                <ul class="list-unstyled clear-margins"><!-- widgets -->
                    <li class="widget-container widget_nav_menu"><!-- widgets list -->
                        <h1 class="title-widget">About US</h1>
                        <ul>
                            <li class="scroll "><a href="mission.html" title="Surgenex Mission"> Our Mission</a></li>
                            <!--<li class="scroll "><a href="harvard-study.html"> Research Studies</a></li>-->
                            <li class="scroll "><a target="_blank" href="http://www.surgenexreviews.com/"  title="SurForce Customers Testimonials"> Testimonials</a></li>
                        </ul>
                    </li>
                </ul>
            </div><!-- widgets column left end -->
        </div>
        <p> <small>&copy; 2017 SURGENEX<sup>®</sup> LLC</small>
    </div>
</footer><!--/#footer-->

</body>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://kit.fontawesome.com/8cdc8fe4fb.js" crossorigin="anonymous"></script>



</html>
