@extends('fronts.master')

@section('content')

@endsection
