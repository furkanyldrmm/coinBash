@extends('fronts.master')
@section('content')
<div class="container">
    <ul class="toplist" style="margin: auto">
        @foreach($all_user as $key=> $user)
        <li data-rank="{{$key+1}}">
            <div class="thumb">
                <img class="img" data-name="BluewaveSwift" src="@if($key==1) {{asset('/assets/images/woman_face.png')}} @else {{asset('/assets/images/face_logo.png')}}  @endif"><span class="name">{{$user->getUser->first_name}}</span>
                <span class="stat"><b>$ {{$user->value}}</b></span>
            </div>
            <div class="more">
                <!-- To be designed & implemented -->
            </div>
        </li>
        @endforeach
            <li data-rank="4">
            <div class="thumb">
                <img class="img" data-name="BluewaveSwift" src="{{asset('/assets/images/face_logo.png')}}"><span class="name">Mehmet</span>
                <span class="stat"><b>$ 900</b></span>
            </div>
            <div class="more">
                <!-- To be designed & implemented -->
            </div>
        </li>


    </ul>
</div>

@endsection
