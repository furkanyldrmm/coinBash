@extends('fronts.master')
@section('content')

    blog
@endsection
