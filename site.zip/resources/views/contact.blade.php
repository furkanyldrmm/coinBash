@extends('fronts.master')
@section('content')
<div class="container contact-form">
    <div class="contact-image">
        <img src="https://image.ibb.co/kUagtU/rocket_contact.png" alt="rocket_contact"/>
    </div>
    <form method="post">
        <h3>Drop Us a Message</h3>
        <div class="row">
            <form method="post">

            <div class="col-md-6">
                    @csrf
                <div class="form-group">
                    <input type="text" name="name" class="form-control"  required placeholder="Your Name *" value="" />
                </div>
                <div class="form-group">
                    <input type="text" name="email" class="form-control"  required placeholder="Your Email *" value="" />
                </div>
                <div class="form-group">
                    <input type="text" name="phone" class="form-control"   placeholder="Your Phone Number *" value="" />
                </div>
                <div class="form-group">
                    <input type="submit" name="btnSubmit" class="btnContact" value="Send Message" />
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <textarea name="msg" class="form-control" required placeholder="Your Message *" style="width: 100%; height: 150px;"></textarea>
                </div>
            </div>
            </form>
        </div>
    </form>
</div>
@endsection
