<?php

namespace App\Http\Controllers;

use App\CoinUser;
use App\ValueUser;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    function loginPage(){
        return view('login');
    }
    function registerPage(){

        return view('register');
    }
    function registerAction(Request $request){

        $credentials = [
            'email'    => $request->email,
            'password' => $request->password,
            'first_name'=>$request->firstname
        ];

        $user = Sentinel::registerAndActivate($credentials);

        if($user){
            $valueUser=new ValueUser;
            $valueUser->user_id=$user->id;
            $valueUser->value=1000;
            $valueUser->save();

            $coinUser=new CoinUser;
            $coinUser->user_id=$user->id;
            $coinUser->coin_name='USD';
            $coinUser->value=1000;
            $coinUser->save();

            return redirect()->back();
        }
        else{
            return  redirect();
        }

    }

    function loginAction(Request $request){
        $credentials = [
            'email'    => $request->nickname,
            'password' => $request->password
        ];

        $user=    Sentinel::authenticateAndRemember($credentials);
        if($user){
            return redirect('/');
        }
        else{
            return redirect()->back();
        }
    }

    function logout(){

        $user = Sentinel::getUser();

        Sentinel::logout($user);
        return redirect('/');
    }
}
