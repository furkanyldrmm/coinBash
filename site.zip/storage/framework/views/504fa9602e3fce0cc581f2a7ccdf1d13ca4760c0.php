<?php $__env->startSection('content'); ?>


    <div class="container">

       <table class="table table-responsive-md table-striped" id="myTable">
           <thead>
           <tr>
               <th scope="col"></th>
               <th scope="col">Pair</th>
               <th scope="col">Unit Value</th>
               <th scope="dolar">Dolar Value</th>


           </tr>
           </thead>
           <tbody>
           <?php $__currentLoopData = $user_coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               <tr>
                   <td scope="row"><img class="coin-icon" src="<?php echo e($coin->getCoin->src); ?>"></td>

                   <td><?php echo e($coin->coin_name); ?></td>
                   <td><?php echo e($coin->value); ?></td>
                   <td><?php echo e(dolarPrice($coin->value,$coin->coin_name)); ?></td>

               </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
       </table>

        <table class="table table-responsive-md table-striped" id="myTable">
            <thead>
            <tr>
                <th scope="col"></th>
                <th scope="col">Type</th>
                <th scope="col">Pair</th>
                <th scope="col">Unit Value</th>
                <th scope="dolar">Dolar Value</th>
                <th scope="col">Date</th>



            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td scope="row"><img class="coin-icon" src="<?php echo e($operation->getCoin->src); ?>"></td>
                    <td class="<?php if($operation->type=="buy"): ?> btn btn-success <?php else: ?> btn btn-danger <?php endif; ?>"><?php echo e($operation->type); ?>  </td>
                    <td><?php echo e($operation->coin_name); ?></td>
                    <td><?php echo e($operation->unit_value); ?></td>
                    <td><?php echo e($operation->value); ?></td>
                    <td><?php echo e($operation->created_at); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fronts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\furkan y\Desktop\coinBash2\resources\views/wallet.blade.php ENDPATH**/ ?>