<?php $__env->startSection('content'); ?>
    <style>
        body{
            overflow: hidden;

        }
        .register-form{
            background-color: #fefefe;
opacity: 0.9;
            width: 50%;
            margin:auto;
            padding:50px;
        }

        .form-title{
            text-align: center;
        }
        .container{
        }
    </style>
    <div class="back">
        <section style="height: 50px"></section>
        <div class="register-form">
        <h2 class="form-title"> coinBash</h2>
        <form action="<?php echo e(route('loginAction')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="firstname">NickName</label>
                <input type="text" class="form-control" id="exampleInputfirstname" name="nickname">
            </div>

            <div class="form-group">
                <label for="Password">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword" name="password">
            </div>
            <button type="submit" class="btn btn-primary col-md-12" name="create">Login</button>
            <p>Join coinbash today !<a style="margin-left: 10px; font-weight: bold; color:#f39c12; " href="/register">Sign Up</a> </p>
        </form>

    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fronts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\furkan y\Desktop\coinBash2\resources\views/login.blade.php ENDPATH**/ ?>