<?php $__env->startSection('content'); ?>
<div class="container">
    <ul class="toplist" style="margin: auto">
        <?php $__currentLoopData = $all_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li data-rank="<?php echo e($key+1); ?>">
            <div class="thumb">
                <img class="img" data-name="BluewaveSwift" src="<?php if($key==1): ?> <?php echo e(asset('/assets/images/woman_face.png')); ?> <?php else: ?> <?php echo e(asset('/assets/images/face_logo.png')); ?>  <?php endif; ?>"><span class="name"><?php echo e($user->getUser->first_name); ?></span>
                <span class="stat"><b>$ <?php echo e($user->value); ?></b></span>
            </div>
            <div class="more">
                <!-- To be designed & implemented -->
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li data-rank="4">
            <div class="thumb">
                <img class="img" data-name="BluewaveSwift" src="<?php echo e(asset('/assets/images/face_logo.png')); ?>"><span class="name">Mehmet</span>
                <span class="stat"><b>$ 900</b></span>
            </div>
            <div class="more">
                <!-- To be designed & implemented -->
            </div>
        </li>


    </ul>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('fronts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\furkan y\Desktop\coinBash2\resources\views/topRank.blade.php ENDPATH**/ ?>