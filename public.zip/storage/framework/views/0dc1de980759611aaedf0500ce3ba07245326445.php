<?php $__env->startSection('content'); ?>
<div class="container">
<div class="profile">



    <div class="card col-md-6 "  style="margin: auto;text-align: center"  >
        <img class="card-img-top" src="<?php if($user->getImage): ?> <?php echo e($user->getImage->image_src); ?> <?php else: ?> https://static.thenounproject.com/png/630729-200.png <?php endif; ?>" alt="Card image cap">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($user->first_name); ?></h5>
            <p class="card-text">Amateur</p>
            <button type="button" class="btn btn-info col-md-12" data-toggle="modal" data-target="#uploadModal">Edit Profile</button>

        </div>
    </div>
    <!-- Modal -->
    <div id="uploadModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 style="text-align: center;width: 100%">Edit Profile</h4>

                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <!-- Form -->
                    <form method='post' action="<?php echo e(route('update-profile')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Nick Name  </label>
                            <input  type="text" name="nickname" class="form-control"  value="<?php echo e($user->first_name); ?>" />
                        </div>
                        <div class="form-group">
                            <label>Profile Photo  </label>
                            <input  type="file"  class="form-control" name="image" />
                        </div>




                        <button type='submit' class='btn btn-info col-md-12'  id='btn_upload'>Edit Profile</button>
                    </form>

                    <!-- Preview-->
                    <div id='preview'></div>
                </div>

            </div>

        </div>
    </div>
</div>


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <?php if(\Illuminate\Support\Facades\Session::has('success_update')): ?>
        <script>
            swal("Good job!", "Your profile information has been updated successfully", "success");

        </script>
        <?php echo \Illuminate\Support\Facades\Session::forget('success_update'); ?>



    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('fronts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\furkan y\Desktop\coinBash2\resources\views/profile.blade.php ENDPATH**/ ?>