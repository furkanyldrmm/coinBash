<?php $__env->startSection('content'); ?>

    blog
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fronts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\furkan y\Desktop\coinBash2\resources\views/blog.blade.php ENDPATH**/ ?>