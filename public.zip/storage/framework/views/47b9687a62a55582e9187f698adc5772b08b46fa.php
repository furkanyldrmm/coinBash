<?php $__env->startSection('content'); ?>
    
<?php $__env->startSection('content'); ?>
    <style>
        body{
            overflow: hidden;

        }
        .register-form{
            background-color: #fefefe;
            opacity: 0.9;
            width: 50%;
            margin:auto;
            padding:50px;
        }

        .form-title{
            text-align: center;
        }
        .container{
        }
    </style>
    <div class="back">
        <section style="height: 50px"></section>
        <div class="register-form">
            <h2 class="form-title">Join coinBash</h2>
            <form action="<?php echo e(route('registerAction')); ?>" method="post">

                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="firstname">NickName</label>
                    <input type="text" class="form-control" id="exampleInputfirstname" name="firstname" required>
                </div>

                <div class="form-group">
                    <label for="Password">E-mail</label>
                    <input type="email"  class="form-control" id="exampleInputPassword" name="email" required>
                </div>

                <div class="form-group">
                    <label for="Password">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary col-md-12" name="create">Sign Up</button>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php if(\Illuminate\Support\Facades\Session::has('register_error')): ?>
    <script>
        swal("Oops sorry!", "There was an error signing up, please try again.", "error");

    </script>
    <?php echo \Illuminate\Support\Facades\Session::forget('register_error'); ?>




<?php endif; ?>


<?php if(\Illuminate\Support\Facades\Session::has('register_nick')): ?>
    <script>
        swal("Oops sorry!", "This nickname has been used before.", "error");

    </script>
    <?php echo \Illuminate\Support\Facades\Session::forget('register_nick'); ?>




<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('fronts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('fronts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\furkan y\Desktop\coinBash2\resources\views/register.blade.php ENDPATH**/ ?>