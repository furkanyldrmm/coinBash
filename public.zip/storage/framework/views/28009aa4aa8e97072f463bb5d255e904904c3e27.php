<?php $__env->startSection('content'); ?>
  <div class="container">
      <div class="tablo">
      <h3 style="text-align: center">will be updated soon</h3>
  </div>
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('fronts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\furkan y\Desktop\coinBash2\resources\views/news.blade.php ENDPATH**/ ?>