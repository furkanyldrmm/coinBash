</body>
</html>
<?php /**PATH C:\Users\furkan y\Desktop\coinBash2\resources\views/front/footer.blade.php ENDPATH**/ ?>