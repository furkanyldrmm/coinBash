@include('fronts.header')
@yield('content')
@include('fronts.footer')
@yield('js')
