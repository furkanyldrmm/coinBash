

<footer>
    <div class="footer">
        <div class="column">
            <ul>
                <li class="title"><span class="first-b">coin</span><span class="second-b">Bash</span></li>
                <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>
            </ul>
        </div>

        <div class="column">
            <ul>
                <li class="title">OTHER LINKS</li>
                <li><a href="#">Terms</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Cookie Policy</a></li>
                <li><a href="#">Tickets</a></li>
            </ul>
        </div>

        <div class="column">
            <ul>
                <li class="title">SHORT CUT</li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">Our Services</a></li>
                <li><a href="#">Our Mission</a></li>
                <li><a href="#">About Us</a></li>
            </ul>
        </div>

        <div class="column">
            <ul>
                <li class="title">SOCIAL</li>

                <li>  <a href="#" title="Address,State,Country,Pincode">Gmail<i class="fa fa-envelope"></i></a></li>
                <li>  <a href="#"> Telegram<i class="fa fa-telegram"></i></a></li>
                   <li> <a href="#"> Instagram <i class="fa fa-instagram"></i></a></li>
            </ul>
        </div>
    </div>
</footer>
<div class="sub-footer">
    | COINBASH Copyright © 2021 CoinBash- All rights reserved |
</div>

</body>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://kit.fontawesome.com/8cdc8fe4fb.js" crossorigin="anonymous"></script>



</html>
