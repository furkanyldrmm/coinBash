@extends('fronts.master')

@section('content')
  <div class="container">
      <div class="tablo">
      <h3 style="text-align: center">will be updated soon</h3>
  </div>
  </div>
@endsection

